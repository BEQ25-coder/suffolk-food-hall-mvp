import { AdminBookingsList } from "@/components/AdminBookingsList";
import { AppShell } from "@/components/AppShell";
import { SectionCard } from "@/components/SectionCard";
import { StatusMessage } from "@/components/StatusMessage";
import { getSortedBookings } from "@/lib/bookings-store";
import type { BookingRecord } from "@/lib/types";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  let loadError = false;
  let bookings: BookingRecord[] = [];

  try {
    bookings = await getSortedBookings();
  } catch (error) {
    console.error("Failed to load admin bookings:", error);
    loadError = true;
  }

  return (
    <AppShell>
      <SectionCard title="Admin bookings" subtitle="Manage events and bookings">
        <p className="mb-4 text-sm leading-6 text-bark/70">
          Review booking requests and update their status.
        </p>

        {loadError ? (
          <StatusMessage variant="error">
            We&apos;re unable to load booking requests right now. Please refresh and try again.
          </StatusMessage>
        ) : (
          <AdminBookingsList initialBookings={bookings} />
        )}
      </SectionCard>
    </AppShell>
  );
}
